# Ejemplo API REST con autentificación Laravel 8 

Tutorial en [Laravel 8 API REST con autentificación JWT](https://andresledo.es/php/laravel/api-rest-autentificacion-jwt/) 
